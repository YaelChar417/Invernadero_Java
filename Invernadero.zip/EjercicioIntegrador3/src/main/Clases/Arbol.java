package main.Clases;

public class Arbol extends Planta{
    //atributos clase Arbol + atributos clase Planta
    private String variedad, tipoTronco, color, tipoHojas;
    private double radioTronco;
    
    //Constructor vacio
    public Arbol() {
    }
    
    //Constructor con parametros
    public Arbol(String variedad, String tipoTronco, String color, 
            String tipoHojas, double radioTronco, String nombre, 
            String climaIdeal, double altoTallo, boolean tieneHojas) {
        super(nombre, climaIdeal, altoTallo, tieneHojas);
        this.variedad = variedad;
        this.tipoTronco = tipoTronco;
        this.color = color;
        this.tipoHojas = tipoHojas;
        this.radioTronco = radioTronco;
    }
    
    /*----- Getter y setter de variedad ------*/
    public String getVariedad() {
        return variedad;
    }

    public void setVariedad(String variedad) {
        this.variedad = variedad;
    }
    /*----------------------------------------*/
    
    /*-- Getter y setter del tipo de tronco --*/
    public String getTipoTronco() {
        return tipoTronco;
    }

    public void setTipoTronco(String tipoTronco) {
        this.tipoTronco = tipoTronco;
    }
    /*----------------------------------------*/
    
    /*----- Getter y setter del color ------*/
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    /*--------------------------------------*/
    
    /*-- Getter y setter del tipo de hojas --*/
    public String getTipoHojas() {
        return tipoHojas;
    }

    public void setTipoHojas(String tipoHojas) {
        this.tipoHojas = tipoHojas;
    }
    /*----------------------------------------*/
    
    /*- Getter y setter del radio del tronco -*/
    public double getRadioTronco() {
        return radioTronco;
    }

    public void setRadioTronco(double radioTronco) {
        this.radioTronco = radioTronco;
    }
    /*-----------------------------------------*/
    
    //Metodo(s) sobreescrito(s)
    @Override
    public void mostrarDatos(){
        System.out.println("""
    Soy un objeto de tipo Arbol
    Mis atributos especiales son: 
    Variedad: %s\t\tTipo tronco: %s
    Color: %s\t\tTipo hojas: %s
    Radio tronco: %s
    -------------------------------------------------------------------------"""
            .formatted(getVariedad(), getTipoTronco(), getColor(), 
            getTipoHojas(), getRadioTronco()));
    }

    @Override
    public String toString() {
        return "Arbol{" + "variedad=" + variedad + ", tipoTronco=" + tipoTronco 
                + ", color=" + color + ", tipoHojas=" + tipoHojas 
                + ", radioTronco=" + radioTronco + '}' + "\n";
    }
    
}
