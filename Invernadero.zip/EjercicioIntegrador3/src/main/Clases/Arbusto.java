package main.Clases;

public class Arbusto extends Planta{
    //Atributos clase Arbusto + atributos clase Planta
    private double ancho;
    private boolean esDomestico, sePodaONo;
    private String variedad, colorHojas;
    //Constructor vacio
    public Arbusto() {
    }
    
    //Constructor con parametros
    public Arbusto(double ancho, boolean esDomestico, boolean sePodaONo, 
            String variedad, String colorHojas, String nombre, 
            String climaIdeal, double altoTallo, boolean tieneHojas){    
        super(nombre, climaIdeal, altoTallo, tieneHojas);
        this.ancho = ancho;
        this.esDomestico = esDomestico;
        this.sePodaONo = sePodaONo;
        this.variedad = variedad;
        this.colorHojas = colorHojas;
    }
    
    /*----- Getter y setter del ancho ------*/
    public double getAncho() {
        return ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }
    /*--------------------------------------*/
    
    /*-- Getter y setter de si es domestico --*/
    public boolean getEsDomestico() {
        return esDomestico;
    }

    public void setEsDomestico(boolean esDomestico) {
        this.esDomestico = esDomestico;
    }
    /*-----------------------------------------*/
    /*----- Getter y setter de si se poda -----*/
    public boolean getSePodaONo() {
        return sePodaONo;
    }

    public void setSePodaONo(boolean sePodaONo) {
        this.sePodaONo = sePodaONo;
    }
    /*------------------------------------------*/
    
    /*----- Getter y setter de variedad -----*/
    public String getVariedad() {
        return variedad;
    }

    public void setVariedad(String variedad) {
        this.variedad = variedad;
    }
    /*---------------------------------------*/
    
    /*-- Getter y setter del color de hojas --*/
    public String getColorHojas() {
        return colorHojas;
    }

    public void setColorHojas(String colorHojas) {
        this.colorHojas = colorHojas;
    }
    /*-----------------------------------------*/

    //Metodo(s) sobreescrito(s)
    @Override
    public void mostrarDatos() {
        System.out.println("""
    Soy un objeto de tipo Arbusto
    Mis atributos especiales son: 
    Ancho: %s\t\tDomestico: %s
    Podar: %s\t\tVariedad: %s
    Color hojas: %s
    -------------------------------------------------------------------------"""
            .formatted(getAncho(), getEsDomestico(), getSePodaONo(), 
            getVariedad(), getColorHojas()));
    }

    @Override
    public String toString() {
        return "Arbusto{" + "ancho=" + ancho + ", esDomestico=" + esDomestico 
                + ", sePodaONo=" + sePodaONo + ", variedad=" + variedad 
                + ", colorHojas=" + colorHojas + '}' + "\n";
    }
    
}
