package main;

import main.Clases.Arbol;
import main.Clases.Arbusto;
import main.Clases.Flor;
import main.Clases.Invernadero;

public class Main {

    public static void main(String[] args) {
        //Instanciar 5 objetos clase Arbol
        Arbol arbol1 = new Arbol("Pino", "Rigido", "Rojo", 
                "Punteadas", 13.50, "Javier", 
                "Templado", 200, true);
        Arbol arbol2 = new Arbol("Pino", "Suave", "Cafe", 
                "Punteadas", 18.80, "Sergio", 
                "Templado", 388, true);
        Arbol arbol3 = new Arbol("Cedro", "Rigido", "Negro", 
                "Redondas", 4.95, "Pedro", 
                "SemiHumedo", 140, true);
        Arbol arbol4 = new Arbol("Cedro", "Suave", "Blanco", 
                "Redondas", 3, "Josue", 
                "SemiHumedo", 54, false);
        Arbol arbol5 = new Arbol("Roble", "Suave", "Cafe", 
                "Redondas", 4, "Julian", 
                "Templado", 200, false);
        
        //Instanciar 5 objetos clase Flor
        Flor flor1 = new Flor("Rosa", "Amarillo", 
                "Peonia", "Verano", 80, "Rosa Linda",
                "Humedo", 12.2, true);
        Flor flor2 = new Flor("Morado", "Naranja", 
                "Peonia", "Primavera", 86, "Julie",
                "SemiHumedo", 13.90, true);
        Flor flor3 = new Flor("Rojo", "Amarillo", 
                "Rosa", "Primavera", 55, "Marie",
                "Humedo", 7.62, true);
        Flor flor4 = new Flor("Naranja", "Amarillo", 
                "Rosa", "Primavera", 53, "Nami",
                "SemiHumedo", 7.48, true);
        Flor flor5 = new Flor("Blanco", "Naranja", 
                "Clavel", "Verano", 12, "Frieren",
                "SemiHumedo", 24.03, true);
        
        //Instanciar 5 objetos clase Arbusto
        Arbusto arbusto1 = new Arbusto(83, false, true, 
                "Floral", "Verde", "Rick", "Calido",
                129, true);
        Arbusto arbusto2 = new Arbusto(48.33, true, true, 
                "Ornato", "Marron", "Patrick", "Templado",
                88.74, true);
        Arbusto arbusto3 = new Arbusto(52.5, true, true, 
                "Floral", "Rosa", "Sheila", "Calido",
                97.80, true);
        Arbusto arbusto4 = new Arbusto(124, false, false, 
                "Ornato", "Verde", "Gary", "Templado",
                228.80, true);
        Arbusto arbusto5 = new Arbusto(15, true,true, 
                "Floral", "Verde", "Gon", "Calido",
                10, true);
        
        //Probar los metodos de las clases Arbol, Flor y Arbusto respectivamente
        arbol3.mostrarDatos();
        flor2.mostrarDatos();
        arbusto5.mostrarDatos();
        
        //Instanciar un objeto de la clase invernadero
        Invernadero inv = new Invernadero();
        
        //Agregar los objetos de arboles a su lista
        inv.agregarArbol(arbol1);
        inv.agregarArbol(arbol2);
        inv.agregarArbol(arbol3);
        inv.agregarArbol(arbol4);
        inv.agregarArbol(arbol5);
        
        //Agregar los objetos de flores a su lista
        inv.agregarFlor(flor1);
        inv.agregarFlor(flor2);
        inv.agregarFlor(flor3);
        inv.agregarFlor(flor4);
        inv.agregarFlor(flor5);
        
        //Agregar los objetos de arbustos a su lista
        inv.agregarArbusto(arbusto1);
        inv.agregarArbusto(arbusto2);
        inv.agregarArbusto(arbusto3);
        inv.agregarArbusto(arbusto4);
        inv.agregarArbusto(arbusto5);
        
        //Quitar el primer y utimo de los objetos para probar el metodo quitar
        inv.quitarArbol(1); inv.quitarArbol(4); 
        inv.quitarFlor(1); inv.quitarFlor(4);
        inv.quitarArbusto(1); inv.quitarArbusto(4);
        
        //mostramos los arboles registrados 
        inv.mostrarArbolesRegistrados();
        
        //mostramos las flores Registradas
        inv.mostrarFloresRegistradas();
        
        //mostramos los arbustos registrados
        inv.mostrarArbustosRegistrados();
        
        //Buscar arboles por un tipo especifico de String
        inv.buscarArboles();
        
        //Buscar flores por un tipo especifico de String
        inv.buscarFlores();
        
        //Buscar arbustos por un tipo especifico de String
        inv.buscarArbustos();
    }
    
}
