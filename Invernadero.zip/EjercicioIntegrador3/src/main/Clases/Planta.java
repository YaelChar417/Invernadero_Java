package main.Clases;

public abstract class Planta {
    //Atributos de la clase Planta
    private String nombre, climaIdeal;
    private double altoTallo;
    private boolean tieneHojas;
    
    //Constructor vacio:
    public Planta() {
    }
    
    //Constructor con parametros:
    public Planta(String nombre, String climaIdeal, double altoTallo, 
            boolean tieneHojas) {
        this.nombre = nombre;
        this.climaIdeal = climaIdeal;
        this.altoTallo = altoTallo;
        this.tieneHojas = tieneHojas;
    }
    
    /*----- Getter y setter del nombre -----*/
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /*--------------------------------------*/
    
    /*--- Getter y setter del clima ideal ---*/
    public String getClimaIdeal() {
        return climaIdeal;
    }

    public void setClimaIdeal(String climaIdeal) {
        this.climaIdeal = climaIdeal;
    }
    /*----------------------------------------*/
    
    /*-- Getter y setter del alto del tallo --*/
    public double getAltoTallo() {
        return altoTallo;
    }

    public void setAltoTallo(double altoTallo) {
        this.altoTallo = altoTallo;
    }
    /*----------------------------------------*/
    
    /*- Getter y setter de si tiene hojas o no -*/
    public boolean getTieneHojas() {
        return tieneHojas;
    }

    public void setTieneHojas(boolean tieneHojas) {
        this.tieneHojas = tieneHojas;
    }
    /*------------------------------------------*/
    
    //Metodo(s) abstracto(s)
    public abstract void mostrarDatos();
    
}
