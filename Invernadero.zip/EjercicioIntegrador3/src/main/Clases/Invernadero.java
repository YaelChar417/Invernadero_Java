package main.Clases;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Invernadero {
    //Scanner para leer datos
    Scanner leer = new Scanner(System.in);
    //Atributos clase Invernadero:
    private int arbolesRegistrados = 0;
    private int floresRegistradas = 0;
    private int arbustosRegistrados = 0;
    public List<Arbol> listaArboles = new ArrayList<Arbol> (); //agregacion
    public List<Flor> listaFlores = new ArrayList<Flor> (); //agregacion
    public List<Arbusto> listaArbustos = new ArrayList<Arbusto> (); //agregacion
    
    //Constructor vacio
    public Invernadero() {
    }
    
    /*---- Getter y setter de los arboles registradas ----*/
    public int getArbolesRegistrados() {
        return arbolesRegistrados;
    }

    public void setArbolesRegistrados(int arbolesRegistrados) {
        this.arbolesRegistrados = arbolesRegistrados;
    }
    /*-----------------------------------------------------*/
    
    /*----- Getter y setter de las flores registradas -----*/
    public int getFloresRegistradas() {
        return floresRegistradas;
    }

    public void setFloresRegistradas(int floresRegistradas) {
        this.floresRegistradas = floresRegistradas;
    }
    /*------------------------------------------------------*/
    /*----- Getter y setter de los arbustos registrados -----*/
    public int getArbustosRegistrados() {
        return arbustosRegistrados;
    }

    public void setArbustosRegistrados(int arbustosRegistrados) {
        this.arbustosRegistrados = arbustosRegistrados;
    }
    /*--------------------------------------------------------*/
    
    //Metodos clase Invernadero:
    
    /*  AGREGAR ARBOL
    *
    * Esta funcion recibe un objeto de Arbol y lo agrega a la ArrayList de 
    * arboles, aumentando el atributo de los arboles registrados.
    *
    * @param Arbol obj; Recibe un objeto de tipo Arbol creado desde el main
    * @return 
    */
    public void agregarArbol(Arbol obj){
        listaArboles.add(obj);
        arbolesRegistrados++;
    }
    
    /*  QUITAR ARBOL
    *
    * Esta funcion recibe un indice entero que representa la posicion de un 
    * objeto que se desea eliminar de la ArrayList de Arbol, para mayor 
    * comprension del usuario se usa (indice - 1) para borrar exactamente el 
    * numero que ingrese, además de reducir en uno los arboles registrados.
    *
    * @param int index;
    * @return 
    */
    public void quitarArbol(int index){
        try
        {
            listaArboles.remove(index - 1);
            arbolesRegistrados--;
        }catch(Exception e)
        {
            System.out.println("Se ha ingresado un indice no valido");
        }
    }
    
    /*  AGREGAR FLOR
    *
    * Esta funcion recibe un objeto de Flor y lo agrega a la ArrayList de 
    * flores, aumentando el atributo de las flores registrados.
    *
    * @param Flor obj; Recibe un objeto de tipo Flor creado desde el main
    * @return 
    */
    public void agregarFlor(Flor obj){
        listaFlores.add(obj);
        floresRegistradas++;
    }
    
    /*  QUITAR FLOR
    *
    * Esta funcion recibe un indice entero que representa la posicion de un 
    * objeto que se desea eliminar de la ArrayList de Flor, para mayor 
    * comprension del usuario se usa (indice - 1) para borrar exactamente el 
    * numero que ingrese, además de reducir en uno las flores registradas.
    *
    * @param int index;
    * @return 
    */
    public void quitarFlor(int index){
        try
        {
            listaFlores.remove(index - 1);
            floresRegistradas--;
        }catch(Exception e)
        {
            System.out.println("Se ha ingresado un indice no valido");
        }
    }
    
    /*  AGREGAR ARBUSTO
    *
    * Esta funcion recibe un objeto de Arbusto y lo agrega a la ArrayList de 
    * arbustos, aumentando el atributo de los arbustos registrados.
    *
    * @param Arbusto obj; Recibe un objeto de tipo Arbusto creado desde el main
    * @return 
    */
    public void agregarArbusto(Arbusto obj){
        listaArbustos.add(obj);
        arbustosRegistrados++;
    }
    
    /*  QUITAR ARBUSTO
    *
    * Esta funcion recibe un indice entero que representa la posicion de un 
    * objeto que se desea eliminar de la ArrayList de Arbusto, para mayor 
    * comprension del usuario se usa (indice - 1) para borrar exactamente el 
    * numero que ingrese, además de reducir en uno los arbustos registrados .
    *
    * @param int index;
    * @return 
    */
    public void quitarArbusto(int index){
        try
        {
            listaArbustos.remove(index - 1);
            arbustosRegistrados--;
        }catch(Exception e)
        {
            System.out.println("Se ha ingresado un indice no valido");
        }
    }
    
    /*  MOSTRAR ARBOLES REGISTRADOS
    *
    * Esta funcion, muestra las caracteristicas (atributos) especificos de la
    * clase Arbol, imprimiendolos en consola, mostrará la de todos los objetos
    * que hayan sido agregados desde el main a la lista de arboles
    *
    * @param 
    * @return 
    */
    public void mostrarArbolesRegistrados(){
        int posicion = 1;
        System.out.println("\t\tARBOLES");
        for (Arbol a : listaArboles)
        {
            System.out.println("""
                               Arbol: %s\t\t\tVariedad: %s
                               Tipo tronco: %s\t\tTipo hojas: %s
                               Radio tronco: %s\t\tAlto arbol: %s
                               Clima ideal: %s\t\tTiene hojas: %s
                               ----------------------------------------------"""
                .formatted(posicion, a.getVariedad(), 
                        a.getTipoTronco(),a.getTipoHojas(), 
                        a.getRadioTronco(), a.getAltoTallo(), 
                        a.getClimaIdeal(), a.getTieneHojas()));
            posicion++;
        }
    }
    
    /*  MOSTRAR FLORES REGISTRADAS
    *
    * Esta funcion, muestra las caracteristicas (atributos) especificos de la
    * clase Flor, imprimiendolos en consola, mostrará la de todos los objetos
    * que hayan sido agregados desde el main a la lista de flores
    *
    * @param 
    * @return 
    */
    public void mostrarFloresRegistradas(){
        int posicion = 1;
        System.out.println("\t\tFLORES");
        for(Flor f : listaFlores)
        {
            System.out.println("""
                               Flor: %s\t\t\t\tVariedad: %s
                               Color petalo: %s\t\tColor pistilo: %s
                               Estacion: %s\t\tClima ideal: %s
                               Cantidad petalos: %s\t\tAltura flor: %s
                               ----------------------------------------------"""
                    .formatted(posicion, f.getVariedad(), 
                            f.getColorPetalos(), f.getColorPistilo(), 
                            f.getEstacion(), f.getClimaIdeal(), 
                            f.getCantidadPetalos(), f.getAltoTallo()));
            posicion++;
        }
    }
    
    /*  MOSTRAR ARBUSTOS REGISTRADOS
    *
    * Esta funcion, muestra las caracteristicas (atributos) especificos de la
    * clase Arbusto, imprimiendolos en consola, mostrará la de todos los objetos
    * que hayan sido agregados desde el main a la lista de arbustos
    *
    * @param 
    * @return 
    */
    public void mostrarArbustosRegistrados(){
        int posicion = 1;
        System.out.println("\t\tARBUSTOS");
        for(Arbusto a : listaArbustos)
        {
            System.out.println("""
                               Arbusto: %s\t\t\tDomestico: %s
                               Variedad: %s\t\tSe poda: %s
                               Ancho arbusto: %s\t\tAltura arbusto: %s
                               Color arbusto: %s\t\tClima: %s
                               ----------------------------------------------"""
                    .formatted(posicion, a.getEsDomestico(), 
                            a.getVariedad(),a.getSePodaONo(), 
                            a.getAncho(), a.getAltoTallo(), 
                            a.getColorHojas(), a.getClimaIdeal()));
            posicion++;
        }
    }
    
    /*  BUSCAR ARBOLES
    *
    * Esta funcion, mostrará al usuario un menú para decidir por cual atributo 
    * desea buscar objetos de tipo Arbol registrados en la ArrayList 
    * correspondiente, para enseguida preguntarle el atributo en si y mostrar
    * los objetos que cumplan con esto, cabe recalcar que como todos son String
    * no se podría implementar una sobrecarga por eso se optó por hacer menu y 
    * usar un rule switch para el manejo de las opciones
    *
    * @param 
    * @return 
    */
    public void buscarArboles(){
        int opcion;
        String var;
        
        System.out.println("""
                           \t\tARBOLES
                           Deseas buscar arboles por...
                           1.- Variedad.
                           2.- Tipo de tronco.
                           3.- Color.
                           4.- Clima ideal.
                           Ingresa la opcion deseada: """);
        opcion = leer.nextInt(); leer.nextLine(); //para evitar error de lectura
        
        switch(opcion)
        {
            case 1-> // el usuario desea buscar por variedad
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                var = leer.nextLine();
                for(Arbol a : listaArboles)
                {
                    if(var.equals(a.getVariedad()))
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            case 2 ->// el usuario desea buscar por tipo de tronco
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                var = leer.nextLine();
                for(Arbol a : listaArboles)
                {
                    if(var.equals(a.getTipoTronco()))
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            case 3->// el usuario desea buscar por color
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                var = leer.nextLine();
                for(Arbol a : listaArboles)
                {
                    if(var.equals(a.getColor()))
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            case 4-> // el usuario desea buscar por clima ideal
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                var = leer.nextLine();
                for(Arbol a : listaArboles)
                {
                    if(var.equals(a.getClimaIdeal()))
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            default -> System.out.println("No se reconocio la opcion");
        }
        System.out.println("\n");
    }
    
    /*  BUSCAR FLORES
    *
    * Esta funcion, mostrará al usuario un menú para decidir por cual atributo 
    * desea buscar objetos de tipo Flor registrados en la ArrayList 
    * correspondiente, para enseguida preguntarle el atributo en si y mostrar
    * los objetos que cumplan con esto, cabe recalcar que como todos son String
    * no se podría implementar una sobrecarga por eso se optó por hacer menu y 
    * usar un rule switch para el manejo de las opciones
    *
    * @param 
    * @return 
    */
    public void buscarFlores(){
        int opcion;
        String var;
        
        System.out.println("""
                           \t\tFLORES
                           Deseas buscar flores por...
                           1.- Variedad.
                           2.- Color de petalos.
                           3.- Color de pistilo.
                           4.- Clima ideal.
                           5.- Estacion.
                           Ingresa la opcion deseada: """);
        opcion = leer.nextInt(); leer.nextLine(); //para evitar error de lectura
        
        switch(opcion)
        {
            case 1-> // el usuario desea buscar por variedad
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                var = leer.nextLine();
                for(Flor f : listaFlores)
                {
                    if(var.equals(f.getVariedad()))
                    {
                        System.out.print(f.toString());
                    }
                }
            }
            case 2 ->// el usuario desea buscar por color de petalos
            {
                System.out.println("Ingresa el atributo especifico a buscar: ");
                var = leer.nextLine();
                for(Flor f : listaFlores)
                {
                    if(var.equals(f.getColorPetalos()))
                    {
                        System.out.print(f.toString());
                    }
                }
            }
            case 3->// el usuario desea buscar por color de pistilo
            {
                System.out.println("Ingresa el atributo especifico a buscar: ");
                var = leer.nextLine();
                for(Flor f : listaFlores)
                {
                    if(var.equals(f.getColorPistilo()))
                    {
                        System.out.print(f.toString());
                    }
                }
            }
            case 4-> // el usuario desea buscar por clima ideal
            {
                System.out.println("Ingresa el atributo especifico a buscar: ");
                var = leer.nextLine();
                for(Flor f : listaFlores)
                {
                    if(var.equals(f.getClimaIdeal()))
                    {
                        System.out.print(f.toString());
                    }
                }
            }
            case 5-> // el usuario desea buscar por estacion
            {
                System.out.println("Ingresa el atributo especifico a buscar: ");
                var = leer.nextLine();
                for(Flor f : listaFlores)
                {
                    if(var.equals(f.getEstacion()))
                    {
                        System.out.print(f.toString());
                    }
                }
            }
            default -> System.out.println("No se reconocio la opcion");
        }
        System.out.println("\n");
    }
    
    /*  BUSCAR Arbustos
    *
    * Esta funcion, mostrará al usuario un menú para decidir por cual atributo 
    * desea buscar objetos de tipo Arbol registrados en la ArrayList 
    * correspondiente, para en seguida preguntarle el atributo en si y mostrar
    * los objetos que cumplan con esto, en este caso hay atributos String y 
    * Boolean por lo que se podría implementar sobrecarga en teoría pero al ser 
    * mas de 1 por cada uno, no realmente, por ello se opto por un menu y rule 
    * switch para un mejor manejo
    *
    * @param 
    * @return 
    */
    public void buscarArbustos(){
        int opcion;
        String varString;
        boolean varBool;
        
        System.out.println("""
                           \t\tARBUSTOS
                           Deseas buscar arbustos por...
                           1.- Variedad.
                           2.- Clima ideal.
                           3.- Color.
                           4.- Es un arbusto domestico.
                           5.- Se tiene que podar.
                           Ingresa la opcion deseada: """);
        opcion = leer.nextInt(); leer.nextLine(); //para evitar error de lectura
        
        switch(opcion)
        {
            case 1-> // el usuario desea buscar por variedad
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                varString = leer.nextLine();
                for(Arbusto a : listaArbustos)
                {
                    if(varString.equals(a.getVariedad()))
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            case 2 ->// el usuario desea buscar por clima ideal
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                varString = leer.nextLine();
                for(Arbusto a : listaArbustos)
                {
                    if(varString.equals(a.getClimaIdeal()))
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            case 3->// el usuario desea buscar por color
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                varString = leer.nextLine();
                for(Arbusto a : listaArbustos)
                {
                    if(varString.equals(a.getColorHojas()))
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            case 4-> // el usuario desea buscar por si es domestico
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                varBool = leer.nextBoolean();
                for(Arbusto a : listaArbustos)
                {
                    
                    if(varBool == a.getEsDomestico())
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            case 5->// el usuario desea buscar por si se poda
            {
                System.out.println("Ingresa el atributo especifico a buscar:");
                varBool = leer.nextBoolean();
                for(Arbusto a : listaArbustos)
                {
                    if(varBool == a.getSePodaONo())
                    {
                        System.out.print(a.toString());
                    }
                }
            }
            default -> System.out.println("No se reconocio la opcion");
        }
        System.out.println("\n");
    }
}
