package main.Clases;

public class Flor extends Planta{
    //Atributos clase Flor + atributos clase Planta
    private String colorPetalos, colorPistilo, variedad, estacion;
    private int cantidadPetalos;
    
    //Constructor vacio
    public Flor() {
    }
    
    //Constructor con parametros
    public Flor(String colorPetalos, String colorPistilo, String variedad, 
            String estacion, int cantidadPetalos, String nombre, 
            String climaIdeal, double altoTallo, boolean tieneHojas) {
        super(nombre, climaIdeal, altoTallo, tieneHojas);
        this.colorPetalos = colorPetalos;
        this.colorPistilo = colorPistilo;
        this.variedad = variedad;
        this.estacion = estacion;
        this.cantidadPetalos = cantidadPetalos;
    }
    
    /*-- Getter y setter del color de petalos --*/
    public String getColorPetalos() {
        return colorPetalos;
    }

    public void setColorPetalos(String colorPetalos) {
        this.colorPetalos = colorPetalos;
    }
    /*------------------------------------------*/
    
    /*-- Getter y setter del color del pistilo --*/
    public String getColorPistilo() {
        return colorPistilo;
    }

    public void setColorPistilo(String colorPistilo) {
        this.colorPistilo = colorPistilo;
    }
    /*--------------------------------------------*/
    
    /*----- Getter y setter de variedad ------*/
    public String getVariedad() {
        return variedad;
    }

    public void setVariedad(String variedad) {
        this.variedad = variedad;
    }
    /*----------------------------------------*/
    
    /*----- Getter y setter de estacion ------*/
    public String getEstacion() {
        return estacion;
    }

    public void setEstacion(String estacion) {
        this.estacion = estacion;
    }
    /*----------------------------------------*/
    
    /*- Getter y setter de la cantidad de petalos -*/
    public int getCantidadPetalos() {
        return cantidadPetalos;
    }

    public void setCantidadPetalos(int cantidadPetalos) {
        this.cantidadPetalos = cantidadPetalos;
    }
    /*---------------------------------------------*/
    
    //metodo(s) sobreescrito(s)
    @Override
    public void mostrarDatos(){
        System.out.println("""
    Soy un objeto de tipo Flor
    Mis atributos especiales son: 
    Color petalos: %s\t\tColor pistilo: %s
    Variedad: %s\t\tEstacion: %s
    Cantidad petalos: %s
    -------------------------------------------------------------------------"""
    .formatted(getColorPetalos(), getColorPistilo(), getVariedad(), 
            getEstacion(), getCantidadPetalos()));
    }

    @Override
    public String toString() {
        return "Flor{" + "colorPetalos=" + colorPetalos 
                + ", colorPistilo=" + colorPistilo + ", variedad=" + variedad 
                + ", estacion=" + estacion + ", cantidadPetalos=" 
                + cantidadPetalos + '}' + "\n";
    }
    
    
}
